
public class Monster {

	//Instance Variables
	private String name;
	private int damage;
	private int baseDamage = 45;
	private int health = 1375;
	private int level;
	private double xp;
	private final double xpArray[] = {30.5, 91.5, 274.5, 823.5, 2470.5};
	private String equippedWeaponName;
	
	/**
	 * 
	 * @param weaponInventory
	 * @param weaponIndex The equipped weapon for this character
	 */
	public Monster(Weapon weaponInventory, String name, int weaponIndex) {
		this.equippedWeaponName = weaponInventory.getWeaponName(weaponIndex);
		this.name = name;
		this.level = 0;
	}
	
	/**
	 * 
	 * @param xp
	 */
	public void updateExperience(double xp) {
		this.xp += xp;
		if(this.xp > xpArray[level+1]) {
			level++;
		}
	}
	
	/**
	 * 
	 * @param baseDamage
	 */
	public void setBaseDamage(int baseDamage) {
		this.baseDamage = baseDamage;
	}
	
	/**
	 * Returns true while actor health is positive
	 * @param damage
	 * @param otherActor
	 * @return
	 */
	public boolean updateHealth(Weapon weaponInventory, Monster otherActor) {			
		int healthBuffer = this.health;
		int damageBuffer = otherActor.getDamage(weaponInventory);
		
		int armor = (getArmor(weaponInventory) - otherActor.getArmorPenetration(weaponInventory));
		
		if(armor > 0) {
			healthBuffer -= (damageBuffer - armor);
		}
		else healthBuffer = (this.health - damageBuffer);
	
		if(healthBuffer > 0) {			
			otherActor.updateExperience(15.5);
			this.health = healthBuffer;
			return true;
		}
		else {
			System.out.println(name + " Died!");
			this.health = healthBuffer;
			return false;
		}
	}
	
	/**
	 * 
	 * @return
	 */
	public int getArmor(Weapon weaponInventory) {
		return weaponInventory.getArmorModifier(equippedWeaponName, level);
	}
	
	/**
	 * 
	 * @return
	 */
	public int getArmorPenetration(Weapon weaponInventory) {
		return weaponInventory.getArmorPenetrationModifier(equippedWeaponName, level);
	}
	
	public String getWeaponName() {
		return this.equippedWeaponName;
	}
	
	/**
	 * 
	 * @return
	 */
	public int getLevel() {
		return this.level;
	}
	
	public void printHelper() {
		System.out.println();
		System.out.println(name);
		System.out.println("Level: " + level);
		System.out.println("Health: " + health);
		System.out.println("Weapon Equiped: " + equippedWeaponName);
		System.out.println("Damage: " + damage);
		System.out.println();
	}
	
	/**
	 * 
	 * @param weaponInventory
	 * @return
	 */
	public int getDamage(Weapon weaponInventory) {
		if(weaponInventory != null)
		    damage = baseDamage + weaponInventory.damageModifier(equippedWeaponName, level);
		else 
		    damage = baseDamage;
		return damage;
	}
	
	/**
	 * 
	 * @param weaponInventory
	 */
	public void getWeaponInventory(Weapon weaponInventory) {
		for(int i = 0; i < 9; i++) {
			System.out.printf("%-15s %-30s" , weaponInventory.getWeaponName(i), 
					weaponInventory.getDescription(weaponInventory.getWeaponName(i)));
		}
	}
}
