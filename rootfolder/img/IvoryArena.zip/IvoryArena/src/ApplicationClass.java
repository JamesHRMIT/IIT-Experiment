import java.util.Random;

public class ApplicationClass {

	public static void main(String[] args) {
		
		Random r = new Random();
			
		Weapon inventory = new Weapon();
		
		Monster player = new Monster(inventory,"Player One", r.nextInt((8 - 0) + 1) + 0);
		
		Monster minion = new Monster(inventory, "Player Two", r.nextInt((8 - 0) + 1) + 0);
		
		System.out.println("Fight!");
		
		boolean bRunWhile = true;
		int roundCounter = 1;

		do {
			System.out.println("Round!: " + roundCounter);
			bRunWhile = minion.updateHealth(inventory, player);
			minion.printHelper();
			
			if (bRunWhile) {
				bRunWhile = player.updateHealth(inventory, minion);
				player.printHelper();
				roundCounter++;
			}
		}while(bRunWhile);
		
	}
}
