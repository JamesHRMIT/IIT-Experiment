public class Weapon {
	
	public Weapon() {
		//Constructor
	}
	
	String weapon;
	/**
	 * Array of weapon names
	 */
	private final String[] weaponArray = { 
			"Runed Iron Mace", 
			"Warblade", 
			"Hellreaver", 
			"Lightbringer", 
			"Bone Mallet", 
			"Battlehammer", 
			"Warmace", 
			"Possessed Ripper", 
			"Sharpened Impaler", };

	/**
	 * why am i empty? we just don't know.
	 */
	private final String[] descriptions = {
			"", 
			"", 
			"", 
			"", 
			"", 
			"", 
			"", 
			"", 
			"",};
	/**
	 * Statistics for each weapon in the array
	 */
	private final int[] damage = 	{ 45, 	50, 	30, 	55, 	28, 	25, 	48, 	45, 	60, };
	
	private final int[] health = 	{ 300, 	250,	325, 	150, 	400, 	410, 	225, 	285, 	180, };
	
	private final int[] armor = 	{ 0, 	5, 		0, 		8, 		0, 		0, 		8, 		6, 		9, };
	
	private final int[] armorPen = 	{ 5, 	0, 		4, 		0, 		4, 		3, 		5, 		0, 		0, };
	
	/**
	 * this needs to be implemented into the game loop when a weapon is used to be made unavailable for the other player.
	 */
	private final int[] weaponStatus = { 1, 1, 	1, 1, 1, 1, 1, 1, 1, };	
	/**
	 * 
	 * @param index
	 * @return
	 */
	public String getWeaponName(int index) {
		return weaponArray[index];
	}
	
	/**
	 * 
	 * @param weaponName
	 * @return
	 */
	public int damageModifier(String weaponName, int level) {
		int index = weaponIndex(weaponName);	
		return (damage[index] + (damage[index] * level));
	}
	
	/**
	 * 
	 * @param weaponName
	 * @return
	 */
	public int getHealthModifier(String weaponName, int level) {
		int index = weaponIndex(weaponName);
		return health[index];

	}
	
	/**
	 * 
	 * @param weaponName
	 * @return Returns the armor buff for equipped weapon
	 */
	public int getArmorModifier(String weaponName, int level) {
		int index = weaponIndex(weaponName);
		return armor[index];
	}
	
	/**
	 * 
	 * @param weaponName
	 * @return Returns the armor penetration buff for equipped weapon
	 */
	public int getArmorPenetrationModifier(String weaponName, int level) {
		int index = weaponIndex(weaponName);
		return armorPen[index];
	}
	
	/**
	 * Returns the status for weapon
	 * @param weaponName
	 * @param status
	 */
	public void setWeaponStatus(String weaponName, int status) {
		int index = weaponIndex(weaponName);
		weaponStatus[index] = status;
	}
	
	/**
	 * 
	 * @param weaponName
	 * @return
	 */
	public String getDescription(String weaponName) {
		int index = weaponIndex(weaponName);
		// update status of a Toy
		return descriptions[index];
	}
	
	/**
	 * 
	 * @param weaponName
	 * @return
	 */
	public int weaponIndex(String weaponName) {	
		switch (weaponName) {
		case "Runed Iron Mace":
			return 0;
		case "Warblade":
			return 1;
		case "Hellreaver":
			return 2;
		case "Lightbringer":
			return 3;
		case "Bone Mallet":
			return 4;
		case "Battlehammer":
			return 5;
		case "Warmace":
			return 6;
		case "Possessed Ripper":
			return 7;
		case "Sharpened Impaler":
			return 8;
		default:
			return -1;
		}
	
	}
}
